package main

import (
	"flag"
	"log"
	// "github.com/kenticny/gostud/bytecount"
	// "github.com/kenticny/gostud/charcount"
	// "github.com/kenticny/gostud/coloredpoint"
	// "github.com/kenticny/gostud/defertrace"
	// "github.com/kenticny/gostud/eval"
	// "github.com/kenticny/gostud/githubissue"
	// "github.com/kenticny/gostud/intset"
	// "github.com/kenticny/gostud/panictest"
	"github.com/kenticny/gostud/chat"
	"github.com/kenticny/gostud/clock"
	"github.com/kenticny/gostud/countdown"
	"github.com/kenticny/gostud/crawl"
	"github.com/kenticny/gostud/diskusage"
	"github.com/kenticny/gostud/netcat"
	"github.com/kenticny/gostud/pipeline"
	"github.com/kenticny/gostud/request"
	"github.com/kenticny/gostud/reverb"
	"github.com/kenticny/gostud/thumbnail"
	"github.com/kenticny/gostud/warmmer"
)

var module = flag.String("m", "", "module name")
var modules = map[string]func(){
	"clock":     clock.Run,
	"netcat":    netcat.Run,
	"request":   request.Run,
	"reverb":    reverb.Run,
	"pipeline":  pipeline.Run,
	"thumbnail": thumbnail.Run,
	"crawl":     crawl.Run,
	"countdown": countdown.Run,
	"diskusage": diskusage.Run,
	"chat":      chat.Run,
	"warmmer":   warmmer.Run,
}

func main() {
	flag.Parse()
	if *module == "" {
		log.Fatal("Missing parameter: m")
	}
	fn, exist := modules[*module]
	if !exist {
		log.Fatalf("Cannot find module: %s", *module)
	}
	fn()

	// ch := make(chan string)
	// go func() {
	// 	time.Sleep(time.Second * 2)
	// 	ch <- "hehe"
	// }()
	// go func() {
	// 	ch <- "meme"
	// }()
	// for x := range ch {
	// 	fmt.Println(x)
	// }
}
