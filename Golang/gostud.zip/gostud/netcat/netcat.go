package netcat

import (
	"io"
	"log"
	"net"
	"os"
)

func Run() {
	conn, err := net.Dial("tcp", "localhost:8000")
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("Connect to %s\n", conn.RemoteAddr())
	done := make(chan int)
	done2 := make(chan int)
	go func() {
		// log.Println("Goru")
		io.Copy(os.Stdout, conn)
		log.Println("Done")
		done <- 1
	}()
	go func() {
		log.Println("Done2")
		done2 <- 1
	}()
	mustCopy(conn, os.Stdin)
	closeConn(conn)
	// <-done
	// time.Sleep(time.Second * 5)
	// <-done2
}

func closeConn(conn net.Conn) {
	conn.Close()
	log.Printf("Connection %s disconnected", conn.RemoteAddr())
}

func mustCopy(dst io.Writer, src io.Reader) {
	if _, err := io.Copy(dst, src); err != nil {
		log.Fatal(err)
	}
}
