package reverb

import (
	"bufio"
	"fmt"
	"log"
	"net"
)

func Run() {
	listener, err := net.Listen("tcp", "localhost:8000")
	if err != nil {
		log.Fatal(err)
	}
	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Print(err)
			continue
		}
		go handleConn(conn)
	}
}

func echo(c net.Conn, shout string) {
	fmt.Fprintf(c, "%s\n", shout)
}

func handleConn(c net.Conn) {
	echo(c, "Welcome to Robot World!")
	input := bufio.NewScanner(c)
	for input.Scan() {
		echo(c, input.Text())
	}
	// NOTE: ignoring potential errors from input.Err()
	closeConn(c)
}

func closeConn(conn net.Conn) {
	conn.Close()
	log.Printf("Connection %s disconnected", conn.RemoteAddr())
}
