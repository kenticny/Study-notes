package structembed

import (
	"fmt"
)

type Person struct {
	Name   string
	Age    int
	Gender bool
}

func (p *Person) SayHello(name string) {
	if name != "" {
		p.Name = name
	}
	fmt.Println("Hello, my name is " + p.Name)
}

// func ()

type Student struct {
	Person
	StuNo int
	Major string
	Name  string
}

func (s *Student) SayHello(name string) {
	if name != "" {
		s.Name = name
	}
	fmt.Println("I'm a student, my name is " + s.Name)
	s.Person.SayHello(s.Name)
}

func Run() {
	s1 := &Student{}
	s2 := new(Student)
	fmt.Println(s1 == s2)
	// s1.Person.SayHello("hehe")
	s1.SayHello("lu")
	s2.SayHello("")
	s2.SayHello("")
	s1.SayHello("")
}
