package spinner

import (
	"fmt"
	"time"
)

func spinner(delay time.Duration) {
	for {
		for _, r := range `-\|/` {
			fmt.Printf("\r%c", r)
			time.Sleep(delay)
		}
	}
}

var ct int64 = 0

func fib(x int) int {
	if x < 2 {
		return x
	}
	return fib(x-1) + fib(x-2)
}

func fib2(x int) int {
	if x < 2 {
		return x
	}
	previous, next, i, temp := 0, 1, 3, 0
	for i <= x {
		temp = previous + next
		previous = next
		next = temp
		i++
	}
	return previous + next
}

func Run() {
	go spinner(100 * time.Millisecond)
	const n = 45
	// fibN := fib(n) // slow
	fibM := fib2(n)
	// fmt.Printf("\rFibonacci(%d) = %d, rFibonacci2(%d) = %d\n", n, fibN, n, fibM)
	fmt.Printf("\rFibonacci(%d) = %d\n", n, fibM)
}
