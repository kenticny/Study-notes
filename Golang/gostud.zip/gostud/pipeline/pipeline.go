package pipeline

import (
	"fmt"
	"time"
)

func Run() {
	numbersc := make(chan int, 3)
	// squaresc := make(chan int)

	go counter(numbersc)
	// go squares(squaresc, numbersc)
	go printer(numbersc, 1)
	go printer(numbersc, 2)
	printer(numbersc, 3)
}

func counter(out chan<- int) {
	for i := 0; i < 10; i++ {
		// fmt.Printf("Counter produce item: %d\n", i)
		out <- i
		time.Sleep(time.Second * 1)
	}
}
func squares(out chan<- int, in <-chan int) {
	for x := range in {
		// fmt.Printf("Squares handle item: %d\n", x)
		out <- x * x
		time.Sleep(time.Second * 2)
	}
}
func printer(in <-chan int, c int) {
	for x := range in {
		fmt.Printf("x = %d, from: %d\n", x, c)
	}
}
