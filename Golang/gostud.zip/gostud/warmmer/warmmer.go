package warmmer

import (
	"fmt"
	"time"

	"github.com/akhenakh/statgo"
)

var ch chan<- string

func Run() {
	go printCpuInfo()
	go warmmer()
	go warmmer()
	warmmer()
}

func warmmer() {
	sum := 0
	i := 1
	for {
		sum += i
	}
}

func printCpuInfo() {
	s := statgo.NewStat()
	tick := time.Tick(time.Second * 1)
	for {
		<-tick
		fmt.Println(s.CPUStats())
	}
}
