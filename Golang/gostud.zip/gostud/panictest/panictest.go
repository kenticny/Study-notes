package panictest

import (
	"fmt"
	"time"
)

func Demo() {
	defer Logs("Demo")()
	panic("Fail")
	fmt.Println("Ok")
}

func Logs(name string) func() {
	return func() {
		fmt.Printf("Log - %s - %s\n", name, time.Now())
		if p := recover(); p != nil {
			fmt.Println(p)
		}
	}
}

func Run() {
	Demo()
}
