package countdown

import (
	"fmt"
	"os"
	"time"
)

func Run() {
	fmt.Println("Commencing countdown.")
	// RocketLaunch(10)
	// SwapChan()
	ReasonableRocketLaunch(10)
}

func SwapChan() {
	ch := make(chan int, 1)
	for i := 0; i < 10; i++ {
		select {
		case x := <-ch:
			fmt.Println(x) // "0" "2" "4" "6" "8"
		case ch <- i:
		}
	}
}

func ReasonableRocketLaunch(countdown int) {
	ticker := time.NewTicker(1 * time.Second)
	abort := make(chan bool)
	go func() {
		os.Stdin.Read(make([]byte, 1))
		abort <- true
	}()
	for c := countdown; c > 0; c-- {
		select {
		case <-ticker.C:
			fmt.Println(c)
		case <-abort:
			fmt.Println("Abort!!!")
			ticker.Stop()
		}
	}
	fmt.Println("Launch!!!")
}

func RocketLaunch(countdown int) {
	tick := time.Tick(1 * time.Second)
	abort := make(chan struct{})
	go func() {
		os.Stdin.Read(make([]byte, 1))
		abort <- struct{}{}
	}()
	for c := countdown; c > 0; c-- {
		select {
		case <-tick:
			fmt.Println(c)
		case <-abort:
			fmt.Println("Abort!!!")
			return
		}
	}
	fmt.Println("Launch!!!")
}
