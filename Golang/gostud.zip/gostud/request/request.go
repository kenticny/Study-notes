package request

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
)

func Run() {
	osParams := os.Args[1:]
	for _, url := range osParams {
		resp, error := http.Get(url)
		if error != nil {
			fmt.Fprintf(os.Stderr, "Request error: %s\n", error.Error())
			os.Exit(1)
		}
		bs, error := ioutil.ReadAll(resp.Body)
		resp.Body.Close()
		if error != nil {
			fmt.Fprintf(os.Stderr, "Parse body error: %s\n", error.Error())
			os.Exit(1)
		}
		fmt.Printf("%s", bs)
	}
}
