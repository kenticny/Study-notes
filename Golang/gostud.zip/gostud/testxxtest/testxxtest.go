package testxxtest

import (
	"fmt"
	"unicode"
)

func IsLu(name string) bool {
	if name == "Luyun" {
		return true
	}
	return false
}

func IsLo(name string) bool {
	if name == "la" {
		return true
	}
	return false
}

func IsPalindrome(s string) bool {
	var letters []rune
	for _, r := range s {
		if unicode.IsLetter(r) {
			letters = append(letters, unicode.ToLower(r))
		}
	}
	for i := range letters {
		if letters[i] != letters[len(letters)-1-i] {
			return false
		}
	}
	return true
}

func Run() {
	fmt.Println("Do some testing")
}
