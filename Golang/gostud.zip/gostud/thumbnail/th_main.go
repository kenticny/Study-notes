package thumbnail

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"sync"
)

func Run() {
	filenames := []string{
		"/Users/kenticny/Code/go/src/github.com/kenticny/gostud/thumbnail/imgs/t1.jpg",
		"/Users/kenticny/Code/go/src/github.com/kenticny/gostud/thumbnail/imgs/t2.jpg",
		"/Users/kenticny/Code/go/src/github.com/kenticny/gostud/thumbnail/imgs/t3.jpg",
	}

	ch := make(chan string)
	var wg sync.WaitGroup
	for _, f := range filenames {
		wg.Add(1)
		go func(f string) {
			defer wg.Done()
			ch <- f
		}(f)
	}
	go func() {
		wg.Wait()
		close(ch)
	}()
	res := makeThumbnails6(ch)
	// for x := range ch {
	// 	fmt.Println(".j:" + x)
	// }

	fmt.Println(res)

	// tfs, err := makeThumbnails5(filenames)
	// log.Printf("Thumbfiles %s", tfs)
	// if err != nil {
	// 	log.Fatal(err)
	// }
}

func makeThumbnails6(filenames <-chan string) int64 {
	sizes := make(chan int64)
	var wg sync.WaitGroup
	for f := range filenames {
		wg.Add(1)
		go func(f string) {
			defer wg.Done()
			thumb, err := ImageFile(f)
			if err != nil {
				log.Println(err)
				return
			}
			info, err := os.Stat(thumb)
			if err != nil {
				log.Println(err)
				return
			}
			sizes <- info.Size()
		}(f)
	}
	go func() {
		wg.Wait()
		close(sizes)
	}()
	var total int64
	for size := range sizes {
		total += size
	}
	fmt.Printf("total = %d\n", total)
	return total
}

func makeThumbnails5(filenames []string) (thumbfiles []string, err error) {
	type item struct {
		thumbfile string
		err       error
	}
	ch := make(chan item, len(filenames))
	for _, f := range filenames {
		go func(f string) {
			var it item
			it.thumbfile, it.err = ImageFile(f)
			ch <- it
		}(f)
	}
	for range filenames {
		it := <-ch
		if it.err != nil {
			return nil, it.err
		}
		thumbfiles = append(thumbfiles, it.thumbfile)
	}
	return thumbfiles, nil
}

func makeThumbnails4(filenames []string) error {
	errors := make(chan error)
	for _, f := range filenames {
		go func(f string) {
			_, err := ImageFile(f)
			errors <- err
		}(f)
	}
	for range filenames {
		if err := <-errors; err != nil {
			return err
		}
	}
	return nil
}

func makeThumbnails3(filenames []string) {
	ch := make(chan string)
	for _, f := range filenames {
		go func(f string) {
			_, e := ImageFile(f)
			if e != nil {
				log.Fatal(e)
			}
			ch <- f
		}(f)
	}
	for x := range ch {
		log.Printf("%s Done", x)
	}
}

func makeThumbnails2(filenames []string) {
	for _, f := range filenames {
		go ImageFile(f)
	}
}

func makeThumbnails(filenames []string) {
	for _, f := range filenames {
		if _, err := ImageFile(f); err != nil {
			log.Println(err)
		}
	}
}

func ex() {
	input := bufio.NewScanner(os.Stdin)
	for input.Scan() {
		thumb, err := ImageFile(input.Text())
		if err != nil {
			log.Print(err)
			continue
		}
		fmt.Println(thumb)
	}
	if err := input.Err(); err != nil {
		log.Fatal(err)
	}
}
